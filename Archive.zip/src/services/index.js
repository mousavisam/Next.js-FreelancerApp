import userApi from "./user";
import certificateApi from "./certificate";
import skillApi from "./skill";
import faqApi from "./faq";
import taskApi from "./task";

export { userApi, skillApi, faqApi, taskApi, certificateApi };
