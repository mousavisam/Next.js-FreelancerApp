
import { Dashboard as DashboardUI } from "../../components";

const Dashboard = () => {
  return (
    <>
      <DashboardUI />
    </>
  );
};

export default Dashboard;
