import { Faq as FaqUI } from "../../components";

const Faq = () => {
  return (
    <>
      <FaqUI />
    </>
  );
};

export default Faq;
