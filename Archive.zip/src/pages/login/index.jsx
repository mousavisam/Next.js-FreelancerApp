import { Login as LoginUI } from "../../components";

const Login = () => {
  return (
    <>
      <LoginUI />
    </>
  );
};

export default Login;
