import { Register as RegisterUI } from "../../components";

const Register = () => {
  return (
    <>
      <RegisterUI />
    </>
  );
};

export default Register;
