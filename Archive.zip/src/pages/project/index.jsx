import { Project as ProjectUI } from "../../components";

const Project = () => {
  return (
    <>
      <ProjectUI />
    </>
  );
};

export default Project;
