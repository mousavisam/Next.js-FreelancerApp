import { Header as HeaderUI } from "../../components";

const Header = () => {
  return (
    <>
      <HeaderUI />
    </>
  );
};

export default Header;
