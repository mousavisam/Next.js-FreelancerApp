import { Profile as ProfileUI } from "../../components";

const Profile = () => {
  return (
    <>
      <ProfileUI />
    </>
  );
};

export default Profile;
